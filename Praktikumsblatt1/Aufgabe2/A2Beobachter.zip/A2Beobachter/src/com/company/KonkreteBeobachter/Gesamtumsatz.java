package com.company.KonkreteBeobachter;

import com.company.Artikel.Artikel;
import com.company.Beobachter.BeobachterDarst;
import com.company.KonkretesSubjekt.Einkaufsliste;

import java.util.ArrayList;

public class Gesamtumsatz extends BeobachterDarst {


    @Override
    public void aktualisiere(ArrayList<Artikel> einkaufsliste) {

    }

    @Override
    public void aktualisiere() {

    }
}
